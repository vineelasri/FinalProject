```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix,precision_score,recall_score,f1_score,roc_auc_score
```

###### Load the dataset from the CSV file


```python
df = pd.read_csv('AnomaData.csv')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>time</th>
      <th>y</th>
      <th>x1</th>
      <th>x2</th>
      <th>x3</th>
      <th>x4</th>
      <th>x5</th>
      <th>x6</th>
      <th>x7</th>
      <th>x8</th>
      <th>...</th>
      <th>x51</th>
      <th>x52</th>
      <th>x54</th>
      <th>x55</th>
      <th>x56</th>
      <th>x57</th>
      <th>x58</th>
      <th>x59</th>
      <th>x60</th>
      <th>y.1</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>05-01-1999 00:00</td>
      <td>0</td>
      <td>0.376665</td>
      <td>-4.596435</td>
      <td>-4.095756</td>
      <td>13.497687</td>
      <td>-0.118830</td>
      <td>-20.669883</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>29.984624</td>
      <td>10.091721</td>
      <td>-4.936434</td>
      <td>-24.590146</td>
      <td>18.515436</td>
      <td>3.473400</td>
      <td>0.033444</td>
      <td>0.953219</td>
      <td>0.006076</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>05-01-1999 00:02</td>
      <td>0</td>
      <td>0.475720</td>
      <td>-4.542502</td>
      <td>-4.018359</td>
      <td>16.230659</td>
      <td>-0.128733</td>
      <td>-18.758079</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>29.984624</td>
      <td>10.095871</td>
      <td>-4.937179</td>
      <td>-32.413266</td>
      <td>22.760065</td>
      <td>2.682933</td>
      <td>0.033536</td>
      <td>1.090502</td>
      <td>0.006083</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>05-01-1999 00:04</td>
      <td>0</td>
      <td>0.363848</td>
      <td>-4.681394</td>
      <td>-4.353147</td>
      <td>14.127997</td>
      <td>-0.138636</td>
      <td>-17.836632</td>
      <td>0.010803</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>29.984624</td>
      <td>10.100265</td>
      <td>-4.937924</td>
      <td>-34.183774</td>
      <td>27.004663</td>
      <td>3.537487</td>
      <td>0.033629</td>
      <td>1.840540</td>
      <td>0.006090</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>05-01-1999 00:06</td>
      <td>0</td>
      <td>0.301590</td>
      <td>-4.758934</td>
      <td>-4.023612</td>
      <td>13.161566</td>
      <td>-0.148142</td>
      <td>-18.517601</td>
      <td>0.002075</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>29.984624</td>
      <td>10.104660</td>
      <td>-4.938669</td>
      <td>-35.954281</td>
      <td>21.672449</td>
      <td>3.986095</td>
      <td>0.033721</td>
      <td>2.554880</td>
      <td>0.006097</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>05-01-1999 00:08</td>
      <td>0</td>
      <td>0.265578</td>
      <td>-4.749928</td>
      <td>-4.333150</td>
      <td>15.267340</td>
      <td>-0.155314</td>
      <td>-17.505913</td>
      <td>0.000732</td>
      <td>-0.061114</td>
      <td>...</td>
      <td>29.984624</td>
      <td>10.109054</td>
      <td>-4.939414</td>
      <td>-37.724789</td>
      <td>21.907251</td>
      <td>3.601573</td>
      <td>0.033777</td>
      <td>1.410494</td>
      <td>0.006105</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 62 columns</p>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 18398 entries, 0 to 18397
    Data columns (total 62 columns):
     #   Column  Non-Null Count  Dtype  
    ---  ------  --------------  -----  
     0   time    18398 non-null  object 
     1   y       18398 non-null  int64  
     2   x1      18398 non-null  float64
     3   x2      18398 non-null  float64
     4   x3      18398 non-null  float64
     5   x4      18398 non-null  float64
     6   x5      18398 non-null  float64
     7   x6      18398 non-null  float64
     8   x7      18398 non-null  float64
     9   x8      18398 non-null  float64
     10  x9      18398 non-null  float64
     11  x10     18398 non-null  float64
     12  x11     18398 non-null  float64
     13  x12     18398 non-null  float64
     14  x13     18398 non-null  float64
     15  x14     18398 non-null  float64
     16  x15     18398 non-null  float64
     17  x16     18398 non-null  float64
     18  x17     18398 non-null  float64
     19  x18     18398 non-null  float64
     20  x19     18398 non-null  float64
     21  x20     18398 non-null  float64
     22  x21     18398 non-null  float64
     23  x22     18398 non-null  float64
     24  x23     18398 non-null  float64
     25  x24     18398 non-null  float64
     26  x25     18398 non-null  float64
     27  x26     18398 non-null  float64
     28  x27     18398 non-null  float64
     29  x28     18398 non-null  int64  
     30  x29     18398 non-null  float64
     31  x30     18398 non-null  float64
     32  x31     18398 non-null  float64
     33  x32     18398 non-null  float64
     34  x33     18398 non-null  float64
     35  x34     18398 non-null  float64
     36  x35     18398 non-null  float64
     37  x36     18398 non-null  float64
     38  x37     18398 non-null  float64
     39  x38     18398 non-null  float64
     40  x39     18398 non-null  float64
     41  x40     18398 non-null  float64
     42  x41     18398 non-null  float64
     43  x42     18398 non-null  float64
     44  x43     18398 non-null  float64
     45  x44     18398 non-null  float64
     46  x45     18398 non-null  float64
     47  x46     18398 non-null  float64
     48  x47     18398 non-null  float64
     49  x48     18398 non-null  float64
     50  x49     18398 non-null  float64
     51  x50     18398 non-null  float64
     52  x51     18398 non-null  float64
     53  x52     18398 non-null  float64
     54  x54     18398 non-null  float64
     55  x55     18398 non-null  float64
     56  x56     18398 non-null  float64
     57  x57     18398 non-null  float64
     58  x58     18398 non-null  float64
     59  x59     18398 non-null  float64
     60  x60     18398 non-null  float64
     61  y.1     18398 non-null  int64  
    dtypes: float64(58), int64(3), object(1)
    memory usage: 8.7+ MB
    

##### Exploratory Data Analysis (EDA)


```python
df.isnull().sum()
```




    time    0
    y       0
    x1      0
    x2      0
    x3      0
           ..
    x57     0
    x58     0
    x59     0
    x60     0
    y.1     0
    Length: 62, dtype: int64




```python
df.duplicated().sum()
```




    0




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>y</th>
      <th>x1</th>
      <th>x2</th>
      <th>x3</th>
      <th>x4</th>
      <th>x5</th>
      <th>x6</th>
      <th>x7</th>
      <th>x8</th>
      <th>x9</th>
      <th>...</th>
      <th>x51</th>
      <th>x52</th>
      <th>x54</th>
      <th>x55</th>
      <th>x56</th>
      <th>x57</th>
      <th>x58</th>
      <th>x59</th>
      <th>x60</th>
      <th>y.1</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>...</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
      <td>18398.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>0.006740</td>
      <td>0.011824</td>
      <td>0.157986</td>
      <td>0.569300</td>
      <td>-9.958345</td>
      <td>0.006518</td>
      <td>2.387533</td>
      <td>0.001647</td>
      <td>-0.004125</td>
      <td>-0.003056</td>
      <td>...</td>
      <td>-3.357339</td>
      <td>0.380519</td>
      <td>0.173708</td>
      <td>2.379154</td>
      <td>9.234953</td>
      <td>0.233493</td>
      <td>-0.001861</td>
      <td>-0.061522</td>
      <td>0.001258</td>
      <td>0.001033</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.081822</td>
      <td>0.742875</td>
      <td>4.939762</td>
      <td>5.937178</td>
      <td>131.033712</td>
      <td>0.634054</td>
      <td>37.104012</td>
      <td>0.108870</td>
      <td>0.075460</td>
      <td>0.156047</td>
      <td>...</td>
      <td>348.256716</td>
      <td>6.211598</td>
      <td>3.029516</td>
      <td>67.940694</td>
      <td>81.274103</td>
      <td>2.326838</td>
      <td>0.048732</td>
      <td>10.394085</td>
      <td>0.004721</td>
      <td>0.032120</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>-3.787279</td>
      <td>-17.316550</td>
      <td>-18.198509</td>
      <td>-322.781610</td>
      <td>-1.623988</td>
      <td>-279.408440</td>
      <td>-0.429273</td>
      <td>-0.451141</td>
      <td>-0.120087</td>
      <td>...</td>
      <td>-3652.989000</td>
      <td>-187.943440</td>
      <td>-8.210370</td>
      <td>-230.574030</td>
      <td>-269.039500</td>
      <td>-12.640370</td>
      <td>-0.149790</td>
      <td>-100.810500</td>
      <td>-0.012229</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>0.000000</td>
      <td>-0.405681</td>
      <td>-2.158235</td>
      <td>-3.537054</td>
      <td>-111.378372</td>
      <td>-0.446787</td>
      <td>-24.345268</td>
      <td>-0.058520</td>
      <td>-0.051043</td>
      <td>-0.059966</td>
      <td>...</td>
      <td>29.984624</td>
      <td>-3.672684</td>
      <td>0.487780</td>
      <td>-40.050046</td>
      <td>-45.519149</td>
      <td>-1.598804</td>
      <td>0.000470</td>
      <td>0.295023</td>
      <td>-0.001805</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>0.000000</td>
      <td>0.128245</td>
      <td>-0.075505</td>
      <td>-0.190683</td>
      <td>-14.881585</td>
      <td>-0.120745</td>
      <td>10.528435</td>
      <td>-0.009338</td>
      <td>-0.000993</td>
      <td>-0.030057</td>
      <td>...</td>
      <td>29.984624</td>
      <td>0.294846</td>
      <td>0.702299</td>
      <td>17.471317</td>
      <td>1.438806</td>
      <td>0.085826</td>
      <td>0.012888</td>
      <td>0.734591</td>
      <td>0.000710</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>0.000000</td>
      <td>0.421222</td>
      <td>2.319297</td>
      <td>3.421223</td>
      <td>92.199134</td>
      <td>0.325152</td>
      <td>32.172974</td>
      <td>0.060515</td>
      <td>0.038986</td>
      <td>0.001990</td>
      <td>...</td>
      <td>29.984624</td>
      <td>5.109543</td>
      <td>2.675751</td>
      <td>44.093387</td>
      <td>63.209681</td>
      <td>2.222118</td>
      <td>0.020991</td>
      <td>1.266506</td>
      <td>0.004087</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1.000000</td>
      <td>3.054156</td>
      <td>16.742105</td>
      <td>15.900116</td>
      <td>334.694098</td>
      <td>4.239385</td>
      <td>96.060768</td>
      <td>1.705590</td>
      <td>0.788826</td>
      <td>4.060033</td>
      <td>...</td>
      <td>40.152348</td>
      <td>14.180588</td>
      <td>6.637265</td>
      <td>287.252017</td>
      <td>252.147455</td>
      <td>6.922008</td>
      <td>0.067249</td>
      <td>6.985460</td>
      <td>0.020510</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 61 columns</p>
</div>




```python
#df.fillna(df.mean(), inplace=True)
```


```python
# Visualize the distribution of each column
df.hist(figsize=(15, 10), bins=20)
plt.show()
```


    
![png](output_10_0.png)
    


###### Convert Time Column to Correct Datatype


```python
if 'time' in df.columns:
    df['time'] = pd.to_datetime(df['time'], errors='coerce')

    # Extract features like hour, day, month from the 'time' column
    df['hour'] = df['time'].dt.hour
    df['day'] = df['time'].dt.day
    df['month'] = df['time'].dt.month

    # Drop the 'time' column if no longer necessary
    df.drop(columns=['time'], inplace=True)

# Preview changes
print(df.head())
```

       y        x1        x2        x3         x4        x5         x6        x7  \
    0  0  0.376665 -4.596435 -4.095756  13.497687 -0.118830 -20.669883  0.000732   
    1  0  0.475720 -4.542502 -4.018359  16.230659 -0.128733 -18.758079  0.000732   
    2  0  0.363848 -4.681394 -4.353147  14.127997 -0.138636 -17.836632  0.010803   
    3  0  0.301590 -4.758934 -4.023612  13.161566 -0.148142 -18.517601  0.002075   
    4  0  0.265578 -4.749928 -4.333150  15.267340 -0.155314 -17.505913  0.000732   
    
             x8        x9  ...        x55        x56       x57       x58  \
    0 -0.061114 -0.059966  ... -24.590146  18.515436  3.473400  0.033444   
    1 -0.061114 -0.059966  ... -32.413266  22.760065  2.682933  0.033536   
    2 -0.061114 -0.030057  ... -34.183774  27.004663  3.537487  0.033629   
    3 -0.061114 -0.019986  ... -35.954281  21.672449  3.986095  0.033721   
    4 -0.061114 -0.030057  ... -37.724789  21.907251  3.601573  0.033777   
    
            x59       x60  y.1  hour  day  month  
    0  0.953219  0.006076    0   0.0  1.0    5.0  
    1  1.090502  0.006083    0   0.0  1.0    5.0  
    2  1.840540  0.006090    0   0.0  1.0    5.0  
    3  2.554880  0.006097    0   0.0  1.0    5.0  
    4  1.410494  0.006105    0   0.0  1.0    5.0  
    
    [5 rows x 64 columns]
    

###### Feature Engineering & Feature Selection


```python
X = df.drop(columns=['y'])
y = df['y']

# Standardize features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
```

##### Train/Test Split with Sampling Distribution


```python
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, stratify=y, random_state=42)

# Check the distribution of the target variable in the train/test sets
print(f'Train set distribution:\n{y_train.value_counts()}')
print(f'Test set distribution:\n{y_test.value_counts()}')
```

    Train set distribution:
    y
    0    14619
    1       99
    Name: count, dtype: int64
    Test set distribution:
    y
    0    3655
    1      25
    Name: count, dtype: int64
    

##### Metrics for Model Evaluation
For anomaly detection, accuracy might not always be the best metric, especially for imbalanced datasets. You can also use precision, recall, F1-score, or AUC-ROC.


```python
def evaluate_model(y_test, y_pred):
    print(f"Accuracy: {accuracy_score(y_test, y_pred):.2f}")
    print(f"Precision: {precision_score(y_test, y_pred):.2f}")
    print(f"Recall: {recall_score(y_test, y_pred):.2f}")
    print(f"F1 Score: {f1_score(y_test, y_pred):.2f}")
    print(f"ROC AUC: {roc_auc_score(y_test, y_pred):.2f}")
    print("Classification Report:\n", classification_report(y_test, y_pred))
```

###### Model Selection, Training, Predicting, and Assessment


```python
rf = RandomForestClassifier(random_state=42)

# Train the model
rf.fit(X_train, y_train)

# Predict on the test set
y_pred = rf.predict(X_test)

# Evaluate the model
evaluate_model(y_test, y_pred)
```

    Accuracy: 1.00
    Precision: 0.85
    Recall: 0.68
    F1 Score: 0.76
    ROC AUC: 0.84
    Classification Report:
                   precision    recall  f1-score   support
    
               0       1.00      1.00      1.00      3655
               1       0.85      0.68      0.76        25
    
        accuracy                           1.00      3680
       macro avg       0.92      0.84      0.88      3680
    weighted avg       1.00      1.00      1.00      3680
    
    

###### Hyperparameter Tuning and Model Improvement


```python
param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [10, 20, 30],
    'min_samples_split': [2, 5, 10]
}

# Initialize GridSearchCV
#grid_search = GridSearchCV(estimator=rf, param_grid=param_grid, cv=5, scoring='accuracy')
grid_search = GridSearchCV(estimator=rf, param_grid=param_grid, 
                           cv=2, n_jobs=-1, verbose=2, scoring='accuracy')

# Fit grid search
grid_search.fit(X_train, y_train)

# Best parameters
print(f"Best Parameters: {grid_search.best_params_}")

# Evaluate the best model
best_model = grid_search.best_estimator_
y_pred_best = best_model.predict(X_test)
evaluate_model(y_test, y_pred_best)
```

    Fitting 2 folds for each of 27 candidates, totalling 54 fits
    Best Parameters: {'max_depth': 20, 'min_samples_split': 2, 'n_estimators': 200}
    Accuracy: 1.00
    Precision: 0.94
    Recall: 0.68
    F1 Score: 0.79
    ROC AUC: 0.84
    Classification Report:
                   precision    recall  f1-score   support
    
               0       1.00      1.00      1.00      3655
               1       0.94      0.68      0.79        25
    
        accuracy                           1.00      3680
       macro avg       0.97      0.84      0.89      3680
    weighted avg       1.00      1.00      1.00      3680
    
    

###### Model Validation


```python
from sklearn.model_selection import cross_val_score

# Cross-validate the best model using 5-fold cross-validation
cv_scores = cross_val_score(best_model, X_train, y_train, cv=5, scoring='accuracy')

# Print cross-validation results
print(f'Cross-Validation Scores: {cv_scores}')
print(f'Mean Cross-Validation Score: {np.mean(cv_scores):.2f}')
print(f'Standard Deviation of CV Scores: {np.std(cv_scores):.2f}')
```

    Cross-Validation Scores: [0.99592391 0.99592391 0.99558424 0.9969419  0.99660211]
    Mean Cross-Validation Score: 1.00
    Standard Deviation of CV Scores: 0.00
    


```python
y_test_pred = best_model.predict(X_test)

# Evaluate model performance on the test set
evaluate_model(y_test, y_test_pred)
```

    Accuracy: 1.00
    Precision: 0.94
    Recall: 0.68
    F1 Score: 0.79
    ROC AUC: 0.84
    Classification Report:
                   precision    recall  f1-score   support
    
               0       1.00      1.00      1.00      3655
               1       0.94      0.68      0.79        25
    
        accuracy                           1.00      3680
       macro avg       0.97      0.84      0.89      3680
    weighted avg       1.00      1.00      1.00      3680
    
    


```python
cm = confusion_matrix(y_test, y_test_pred)

# Plot Confusion Matrix
plt.figure(figsize=(6, 4))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False, xticklabels=['No Anomaly', 'Anomaly'], yticklabels=['No Anomaly', 'Anomaly'])
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()
```


    
![png](output_26_0.png)
    


As from above metrics we can see that the success metrics of the accuracy of the model on the test data set is > 75%


```python

```
